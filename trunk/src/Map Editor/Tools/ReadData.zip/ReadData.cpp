// ReadData.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ReadData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		char	Filename[1024];
		int		i, j, n = 2299;
		unsigned char		*X[2299];
		printf("Filename:");
		scanf("%s", Filename);
		FILE	*f;
		f=fopen(Filename, "rt");
		

		for (i=0; i<n; i++)
		{
			X[i] = new unsigned char [2299];
			for (j=0; j<n; j++)
			fscanf(f, "%d", &X[i][j]);
		}
		fclose(f);

		int	x, y;
		do 
		{
			printf("Enter coordinates: ");
			scanf("%d %d", &x, &y);
			if (x==-1 || y == -1)
				break;
			printf("%d\n", X[x][y]);
		} while(1);

		for (i=0; i<n; i++)
			delete [] X[i];

	}

	return nRetCode;
}


